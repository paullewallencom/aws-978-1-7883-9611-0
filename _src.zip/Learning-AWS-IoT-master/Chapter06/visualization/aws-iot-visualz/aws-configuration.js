/*
 * NOTE: You must set the following string constants prior to running this
 * example application.
 */
var awsConfiguration = {
   poolId: 'ap-northeast-1:fbeb0b6d-0a70-4d1f-8035-8b17aa3ee240', // 'YourCognitoIdentityPoolId'
   host: 'a9auwf4ykxtac.iot.ap-northeast-1.amazonaws.com', // 'YourAwsIoTEndpoint', e.g. 'prefix.iot.us-east-1.amazonaws.com'
   region: 'ap-northeast-1' // 'YourAwsRegion', e.g. 'us-east-1'
};
module.exports = awsConfiguration;

